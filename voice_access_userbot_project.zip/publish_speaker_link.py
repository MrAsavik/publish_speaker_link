import os
import json
import asyncio
from pathlib import Path
from dotenv import load_dotenv
from telethon import TelegramClient
from telethon.tl.functions.phone import ExportGroupCallInviteRequest
from telethon.tl.functions.messages import PinMessageRequest
from telethon.tl.custom import Button
from telethon.tl.types import InputPeerChannel

# Загрузка .env
load_dotenv()
api_id = int(os.getenv("API_ID"))
api_hash = os.getenv("API_HASH"))
phone = os.getenv("PHONE")
session_name = os.getenv("SESSION_NAME", "voice_access_bot")
client = TelegramClient(session_name, api_id, api_hash)

config = json.loads(Path('config.json').read_text())
print("Доступные каналы:")
for name in config['channels']:
    print(f" - {name}")
channel_name = input("Выберите канал: ").strip()
chan_cfg = config['channels'][channel_name]
channel = InputPeerChannel(chan_cfg['id'], chan_cfg['hash'])

async def main():
    await client.start(phone)
    # Экспорт ссылки с can_self_unmute=True
    invite = await client(ExportGroupCallInviteRequest(
        peer=channel,
        call=None,  # для эфиров канала достаточно peer
        can_self_unmute=True
    ))
    # Публикация и закрепление
    msg = await client.send_message(
        entity=channel,
        message="🎙 **Присоединяйтесь к эфиру сразу как спикер!**\nНажмите кнопку ниже, чтобы войти с правом говорить:",
        parse_mode='md',
        buttons=[Button.url("▶️ Присоединиться и говорить", invite.link)]
    )
    await client(PinMessageRequest(peer=channel, id=msg.id, silent=True))
    print("Ссылка опубликована и закреплена:", invite.link)
    await client.disconnect()

if __name__ == '__main__':
    asyncio.run(main())
