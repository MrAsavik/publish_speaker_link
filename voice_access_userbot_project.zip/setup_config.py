import os
import json
import asyncio
from pathlib import Path
from dotenv import load_dotenv
from telethon import TelegramClient
from telethon.tl.functions.phone import GetGroupCallRequest
from telethon.tl.types import InputPeerChannel

# Загрузка .env
load_dotenv()
api_id = int(os.getenv("API_ID"))
api_hash = os.getenv("API_HASH")
phone = os.getenv("PHONE")
session_name = os.getenv("SESSION_NAME", "voice_access_bot")

client = TelegramClient(session_name, api_id, api_hash)
config_path = Path('config.json')

async def main():
    await client.start(phone)
    # Загрузка текущей конфигурации
    if config_path.exists():
        config = json.loads(config_path.read_text())
    else:
        config = {'channels': {}}

    # Выбор или ввод нового канала
    print("Доступные сохраненные каналы:")
    for name in config['channels']:
        print(f" - {name}")
    channel_name = input("Введите имя канала для настройки или новое имя: ").strip()
    username = input("Введите @username канала (без @): ").strip()

    # Получение информации о канале
    chan = await client.get_entity(username)
    channel_id = chan.id
    channel_hash = chan.access_hash

    # Получение текущего активного эфир
    peer = InputPeerChannel(channel_id, channel_hash)
    result = await client(GetGroupCallRequest(peer=peer, limit=1))
    call = result.call

    # Сохранение в конфиг
    config['channels'][channel_name] = {
        'id': channel_id,
        'hash': channel_hash,
        'last_call': {
            'id': call.id,
            'hash': call.access_hash
        }
    }
    config_path.write_text(json.dumps(config, indent=2), encoding='utf-8')
    print(f"Конфигурация сохранена для канала '{channel_name}' в config.json")

    await client.disconnect()

if __name__ == '__main__':
    asyncio.run(main())
